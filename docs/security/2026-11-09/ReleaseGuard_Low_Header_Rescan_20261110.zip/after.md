# ZAP Scanning Report

ZAP by [Checkmarx](https://checkmarx.com/).


## Summary of Alerts

| Risk Level | Number of Alerts |
| --- | --- |
| High | 0 |
| Medium | 0 |
| Low | 0 |
| Informational | 1 |




## Insights

| Level | Reason | Site | Description | Statistic |
| --- | --- | --- | --- | --- |
| Low | Warning |  | ZAP errors logged - see the zap.log file for details | 8    |
| Info | Informational |  | Percentage of network failures | 57 % |
| Info | Informational | http://gateway:8080 | Percentage of responses with status code 2xx | 66 % |
| Info | Informational | http://gateway:8080 | Percentage of responses with status code 4xx | 33 % |
| Info | Informational | http://gateway:8080 | Percentage of endpoints with content type application/javascript | 20 % |
| Info | Informational | http://gateway:8080 | Percentage of endpoints with content type application/json | 40 % |
| Info | Informational | http://gateway:8080 | Percentage of endpoints with content type text/css | 20 % |
| Info | Informational | http://gateway:8080 | Percentage of endpoints with content type text/html | 20 % |
| Info | Informational | http://gateway:8080 | Percentage of endpoints with method GET | 100 % |
| Info | Informational | http://gateway:8080 | Count of total endpoints | 5    |







## Alerts

| Name | Risk Level | Number of Instances |
| --- | --- | --- |
| Information Disclosure - Suspicious Comments | Informational | 1 |




## Alert Detail



### [ Information Disclosure - Suspicious Comments ](https://www.zaproxy.org/docs/alerts/10027/)



##### Informational (Medium)

### Description

The response appears to contain suspicious comments which may help an attacker.

* URL: http://gateway:8080/app.js
  * Node Name: `http://gateway:8080/app.js`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `reset a connection, user input or job eviden`
  * Other Info: `The following pattern was used: \bUSER\b and was detected in likely comment: "// Optional metadata must never reset a connection, user input or job evidence.", see evidence field for the suspicious comment/snippet.`


Instances: 1

### Solution

Remove all comments that return information that may help an attacker and fix any underlying problems they refer to.

### Reference



#### CWE Id: [ 615 ](https://cwe.mitre.org/data/definitions/615.html)


#### WASC Id: 13

#### Source ID: 3


